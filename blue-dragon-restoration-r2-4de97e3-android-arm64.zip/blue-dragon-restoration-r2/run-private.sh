#!/data/data/com.termux/files/usr/bin/bash
set -eu
here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
case $(uname -m) in aarch64|arm64) ;; *) echo 'Requires Android ARM64 / Termux (Android 8+).' >&2; exit 1;; esac
(cd "$here" && sha256sum -c SHA256SUMS >/dev/null) || { echo 'Package integrity check failed.' >&2; exit 1; }
state="$HOME/.local/share/blue-dragon-restoration-r2-4de97e3"
project="${BLUE_DRAGON_TRIAL_PROJECT:-$HOME/blue-dragon-restoration-r2-4de97e3-work}"
mkdir -p "$state" "$project"
export BLUE_DRAGON_HOME="$state"
chmod u+x "$here/blue-dragon"
printf '%s\n' 'Restoration R2 4de97e3 — separate trial; not the missing 393ffb0 source.' "Workspace: $project" "State: $state"
if [ "$#" -eq 0 ]; then set -- chat; fi
exec "$here/blue-dragon" --root "$project" "$@"
