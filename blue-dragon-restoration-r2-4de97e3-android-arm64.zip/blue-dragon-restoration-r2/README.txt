Blue Dragon Restoration R2 — 4de97e3
Separate Android ARM64 trial, API26+. Not the lost 393ffb0 source.
Extract inside Termux HOME (not shared Android storage), then:
  bash blue-dragon-restoration-r2/run-private.sh
For TUI:
  bash blue-dragon-restoration-r2/run-private.sh tui
Original installation, settings, sessions and project files are not touched.
This trial uses its own state and workspace. Configure your own provider if needed; no shared credentials are included. The default model was not changed.
To choose an existing project explicitly: BLUE_DRAGON_TRIAL_PROJECT=/absolute/project bash run-private.sh
Review every action approval. The binary still displays package version 0.9.0-alpha.3; the unique source identity is 4de97e3 in this manifest.
Source archive, Git bundle, build/test logs and limitations included. All final acceptance uses local scripted providers; no physical Android or live model test. Chromium startup blocked by environment. A stable original install remains available separately.
