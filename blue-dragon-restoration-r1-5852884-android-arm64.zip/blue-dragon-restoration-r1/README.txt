BLUE DRAGON RESTORATION R1 — PRIVATE ANDROID ARM64 TRIAL

Not the missing 393ffb0 build. Based on archive 8c870f8 plus source commit
5852884a14ffdaecb0237ecc27809b1666537504. Package --version still reports
0.9.0-alpha.3; use BUILD-MANIFEST.json for restoration identity.

Extract in Termux HOME (not shared Android storage) and run:
  bash blue-dragon-restoration-r1/run-private.sh
Default is original CLI chat. Optional original TUI:
  bash blue-dragon-restoration-r1/run-private.sh tui
Command approval is still mandatory; accept y only for the displayed action.
No original app, settings or sessions are overwritten or copied. Trial state and
workspace paths are printed. No keys are included. This remains a provider-backed
agent: binary/tools run on the phone; model requests require its configured service.
A provider's availability, free quota or response quality is not guaranteed.
Use BLUE_DRAGON_TRIAL_PROJECT only to explicitly choose another workspace.

Full exact source tar, complete Git bundle, license, logs and hashes are included.
Rebuild with Cargo --locked, target aarch64-linux-android, NDK r30 API26 clang,
setting CC_aarch64_linux_android, CXX_aarch64_linux_android, AR_aarch64_linux_android
and CARGO_TARGET_AARCH64_LINUX_ANDROID_LINKER to that NDK's corresponding tools.
See build manifest and logs. No phone execution or real browser success is claimed.
There is no installer, hard link, deletion, global symlink or GitHub update.
