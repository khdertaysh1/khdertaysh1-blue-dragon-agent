# Local reliability candidate — 2026-11-22

Base: `a454d682b370522c417da30c6642422e3076c87f`, branch `fix/reliability-local-acceptance`.
No AGENTS.md was present in the recovered checkout or workspace ancestors. This checkout is the available published source, not a reconstruction of previously lost private commits. The attached Android 393ffb0 package was not modified. No release, tag, asset or workflow was changed.

## Confirmed causes and implementation

| Concern | Code and change | Evidence / remaining limits |
|---|---|---|
| Output truncation | `provider_traffic::output_limit` supplies a client default 2048 for Kilo/delegates/TPM configuration. `Provider::configure_output`, wire max_tokens and Agent projection now share the same reserve; `--max-output-tokens` supports explicit bounded configuration and known catalog completion caps. `provider_contract::incomplete_stop` retains scrubbed raw finish reasons in both streaming and nonstreaming paths. | A length stop is not proof of a provider quota. Unknown model ceilings remain unknown. No increase of model context or retry of a partial batch. |
| Historical facts | `reasoning::checkpoint::native_facts` extracts up to six original hash-pinned observations separately from model prose, with source IDs, arguments excerpt, hashes, coverage and historical status. `context::recall` labels original tool records versus model statements. | Projection/restart test preserves a function definition, rejects altered hash and does not promote contradictory assistant prose. Bounded extractive history, not complete semantic memory or proof of current state. |
| Browser recovery | `Browser::invoke` records uncertain mutation before dispatch, preserves the barrier on oversize/transport failure, classifies failed reads separately and requires a fresh top-level snapshot before another mutation. Shared page snapshot offers compact URL/title/h1/elements. | Oversize mutation then altered click is blocked. CDP and extension use the same page code. Real Chromium blocked by environment socket permission; no sandbox bypass. |
| Stalling | `reasoning::loops::Guard` resets stagnation counters on new native evidence, retaining cumulative counters and denied/unknown barriers. `Agent::turn` requests a bounded summary without further tools when stalled, labels it partial and exits nonzero. | This is conservative evidence-change detection, not a general proof of progress or task completion. |
| Search | `search_file` schema and native result state literal semantics, query, scanned coverage and limits of absence claims. | Local import/export alias fixture reads complete surrounding lines; no regex or semantic/dataflow engine was added. |
| Empty checks | `TaskChecks::needs_review/status` distinguishes not_declared from missing/failed/stale declared checks. Agent returns answer_returned_no_acceptance_contract rather than claiming verified. | Before: file create/read returned needs_verification and 5 provider requests. After: 4 requests, no automatic failure for empty checks. Neither exit 0 nor empty checks proves semantic correctness. |
| Argument/batch recovery | Recall count schema/runtime share 12000. Tool batches over 8 are rejected before execution, with one corrective opportunity. Same-tool successful correction clears its incident counter while total errors remain bounded. | Recall 12001→100 and batch 9→1 are exercised. Broken JSON is never guessed; original approval stays required. |

## Verification

- `cargo test --quiet`: 383 tests passed.
- `cargo clippy --all-targets -- -D warnings`: passed.
- Shared browser transport/forms/policy JavaScript contract tests passed, including compact DOM result.
- `scripts/accept_reliability_local.py`: nine local scripted-provider cases: approval waits, rejection, create/read, literal search with alias source lines, oversized batch correction, recall bounds, truncated tool calls (stream/nonstream), 429 after one completed command.
- `scripts/smoke_provider_boundaries.py`: 18 cases (secret redaction and incomplete-stop boundaries).
- `scripts/smoke_quota_resume.py`: nine scripted cases; bounded Retry-After recovery, one original command, no model rotation, no retry of 400/default-300/long delays. These checks do not establish every interactive cooldown/input scenario.
- `scripts/accept_browser_local.py`: local static two-page acceptance prepared; execution blocked before opening a page by Chromium `socket() failed: Operation not permitted`. Not counted as passed.

All provider acceptance runs are local simulations. No live provider, Android/Termux device, Windows or macOS run was performed. No claim of long-session capacity, general factual-report verification, complete preservation of all old details, or completed real-browser acceptance. No external application fixtures/workflows were added. Commands and files are confined to temporary local fixtures with approvals.

## Reproduction

```sh
cargo test
cargo clippy --all-targets -- -D warnings
cargo build --release
python3 scripts/accept_reliability_local.py target/release/blue-dragon
python3 scripts/smoke_provider_boundaries.py target/release/blue-dragon
python3 scripts/smoke_quota_resume.py target/release/blue-dragon
node scripts/test_browser_transport.mjs
node scripts/test_browser_forms.mjs
node scripts/test_browser_policy.mjs
# Requires an environment allowed to launch sandboxed Chromium:
python3 scripts/accept_browser_local.py target/release/blue-dragon
```

Do not install this Linux build on Termux. This is a local review candidate, not a published update.

Final Linux x86_64 executable SHA256: `aed77bdafae78845e79141d690e79fa0d8402fac907f7f712e25cd62b7afab69`. All three final CLI suites recorded this same digest.
