#!/usr/bin/env bash
set -euo pipefail
umask 077
base=$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)
case "$(uname -m)" in aarch64|arm64) ;; *) printf '%s\n' 'This private build needs Android ARM64 (aarch64).' >&2; exit 1;; esac
(cd "$base" && sha256sum --check --status BINARY_SHA256.txt) || { printf '%s\n' 'Binary checksum mismatch; nothing executed.' >&2; exit 1; }
for part in state workspace; do
  [ ! -L "$base/$part" ] || { printf '%s\n' 'Refusing a linked private data directory.' >&2; exit 1; }
  mkdir -p -- "$base/$part"
done
# Preserve the original installation. Read only its model choice on first use.
original_state=${BLUE_DRAGON_HOME:-${XDG_DATA_HOME:-$HOME/.local/share}/blue-dragon}
if [ ! -e "$base/state/model.json" ] && [ ! -L "$base/state/model.json" ] && [ -f "$original_state/model.json" ] && [ ! -L "$original_state/model.json" ]; then
  (set -o noclobber; cat -- "$original_state/model.json" > "$base/state/model.json")
fi
export BLUE_DRAGON_HOME="$base/state"
chmod 700 -- "$base/blue-dragon"
printf '%s\n' 'Private Blue Dragon: ef21e844bc7fd5e0d81041e64a3eb91ac1b3a699' 'Original installation and sessions are unchanged.' "Private data: $BLUE_DRAGON_HOME" "Default test workspace: $base/workspace"
if [ "$#" -eq 0 ]; then
  set -- tui
fi
exec "$base/blue-dragon" --root "$base/workspace" "$@"
