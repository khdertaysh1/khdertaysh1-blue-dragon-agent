#!/data/data/com.termux/files/usr/bin/bash
set -eu
here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
case $(uname -m) in aarch64|arm64) ;; *) echo 'Requires Android ARM64 / Termux (Android 8+).' >&2; exit 1;; esac
(cd "$here" && sha256sum -c SHA256SUMS >/dev/null) || { echo 'Package integrity check failed.' >&2; exit 1; }
state="$HOME/.local/share/blue-dragon-restoration-r6"
project="${BLUE_DRAGON_TRIAL_PROJECT:-$HOME/blue-dragon-restoration-r6-work}"
mkdir -p "$state" "$project"
export BLUE_DRAGON_HOME="$state"
chmod u+x "$here/blue-dragon"
printf '%s\n' 'Blue Dragon R6 d592e43 — Android ARM64' "Workspace: $project" "State: $state"
if [ "$#" -eq 0 ]; then
    if [ -t 0 ] && [ -t 1 ]; then set -- tui; else set -- chat; fi
fi
exec "$here/blue-dragon" --root "$project" "$@"
