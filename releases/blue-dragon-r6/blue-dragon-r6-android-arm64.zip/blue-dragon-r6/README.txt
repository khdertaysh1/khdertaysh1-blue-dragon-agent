Blue Dragon R6 for Android ARM64 / Termux
Run bash run-private.sh from the extracted blue-dragon-r6 folder. On an interactive terminal, the blue Abyss TUI is the default. Pass chat to use the plain CLI. If a TUI startup fails, run bash run-private.sh chat.
The launcher uses separate state and workspace by default. BLUE_DRAGON_TRIAL_PROJECT can point to an existing workspace.
Browser snapshots, network logs, and fetched text are marked session-only. Native file tools identify disk paths and byte counts. Incomplete captures are labeled.
After successful tool evidence, an output-limit interruption may request one compact final report using recorded evidence. Tools are disabled during recovery. Provider quota and rate-limit behavior is unchanged.
Source: git clone source.git.bundle recovered
Verification: local scripted provider on Linux, Rust tests and Android cross-build. No physical-device or live-model test of R6.
